HTML5-canvas-projects
=====================

HTML5 Canvas projects - including simple Thermometer, speedometer, map and compass.