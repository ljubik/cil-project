function testAjax() {
    jQuery('#example-5').html('Test completed');
}