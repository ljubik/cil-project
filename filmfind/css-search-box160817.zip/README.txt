A Pen created at CodePen.io. You can find this one at https://codepen.io/jcoulterdesign/pen/pgwxJR.

 It searches things, probably something similar been done before